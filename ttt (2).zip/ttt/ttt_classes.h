#include <iostream>
#include <array> 
using namespace std;
static int noOfPlayers=0;
extern bool state;
enum XO{X, O, NA};



 class Player;
 class Board{
    XO** board;
    int size;
    Player* p1;
    Player* p2;
    Player* turn;
    Player *winner;
    public:
    
    Board();
    Board(Player *pl1, Player *pl2, int n);
    void place(Player *p, int position);
    
    XO get(int row, int column);
    Player* getTurn();

    void setWinner(Player *player);

    Player getWinner();
    bool validMove(int position);
    void switchTurn();

    //checks one row
    bool checkHorizontal(int start);

    bool checkRows();

    //checks 1 vertical
    bool checkVertical(int start);
    bool checkColumns();

    bool checkDiagonal(int start);
    bool checkDiagonals();

    
    bool checkState();

    friend std::ostream& operator<<(std::ostream& str, const Board &b);

 };

 

 

class Player{
    
    std::string name; 
    XO type;
    Board* game;
    int number;
    
     public:
     Player(XO xo){
        number=noOfPlayers++;
        name="Player "+std::to_string(number);
        type=xo;
     }
     Player(std::string pname, XO xo){
        number=noOfPlayers++;
        name=pname;
        type=xo;
     }
    
    void move(int position){
        (*game).place(this, position);
        
    }


    
    //getters/setters
     void setBoard(Board* board){
         game=board; 
     }
     std::string getName(){
         return name;
     }

     XO getType(){
         return type;
     }
    
     
 };


 