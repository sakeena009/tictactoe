#include <iostream>
#include "ttt_classes.h"

std::ostream& operator<<(std::ostream& str, XO const &value){
     if (value==X){
         std::cout<<"X";
     }else if (value==O){
         std::cout<<"O";
     }else{
         std::cout<<" ";
     }
     
 };
Board::Board(){
        size=3;
        for (int i=0; i<3; i++){
            board[i]=new XO[3]{NA, NA, NA};
        }
        /*size=n;
        board=new XO*[size];
        for (int i=0; i<size; i++){
            for (int j=0; j<size; j++){
                board[i][j]=NA;
            }
        }*/
    }
    Board::Board(Player *pl1, Player *pl2, int n){
        size=n;
        board=new XO*[n];
        for (int i=0; i<n; i++){
            board[i]=new XO[n];
            for(int j=0; j<n;j++){
                board[i][j]=NA;
            }
        }
        p1=pl1;
        p2=pl2;
        turn=pl1;
        
    }
    void Board::switchTurn(){
        if (turn==p1){
            turn=p2;
        }else{
            turn=p1;
        }
    }
    void Board::place(Player *p, int position){
        if (validMove(position)){
            board[position/size][position%size]=p->getType();
            
            if (checkState()){
                state=true;
                winner=p;
            }
            switchTurn();
            
            

        }else{
            std::cout<<"Invalid position."<<std::endl;
        } 

    }
    
    XO Board::get(int row, int column){
        return board[row][column];
    }

    Player* Board::getTurn(){
        return turn;
    }

    void Board::setWinner(Player *player){
        winner=player;
    }

    Player Board::getWinner(){
        return (*winner);
    }
    bool Board::validMove(int position){
        return board[position/size][position%size]==NA;
    }
    

    //checks one row
    bool Board::checkHorizontal(int start){
        XO val=board[start][0];
       
        for (int i=1; i<size; i++){
            if(board[start][i]==NA||board[start][i]!=val){
                return false;
            }

        }
        return true;
    }

    bool Board::checkRows(){
        for (int i=0; i<size; i++){
            if (checkHorizontal(i)){
                return true;
            }
        }
        return false;
    }

    //checks 1 vertical
    bool Board::checkVertical(int start){
        XO val=board[0][start];
        
        for (int i=1; i<size; i++){
            if(board[i][start]==NA||board[i][start]!=val){
                return false;
            }

        }
        return true;
    }
    bool Board::checkColumns(){
        for (int i=0; i<size; i++){
            if (checkVertical(i)){
                return true;
            }
        }
        return false;
    }

    bool Board::checkDiagonal(int start){
        
        int j;
        if (start<0){
            j=2;
            XO val=board[0][j];
            for(int i=0; i<size; i++){
            if (board[i][j]==NA||board[i][j]!=val){
                return false;
            }
            j--;

        }
        return true;
        }else{
            j=0;
            XO val=board[0][j];
            for(int i=0; i<size; i++){
            if (board[i][j]==NA||board[i][j]!=val){
                return false;
            }
            j++;

        }
        return true;
        }
        
    }
    bool Board::checkDiagonals(){
        if (checkDiagonal(0)){
            return true;
        }else{ 
            return checkDiagonal(-1);
        }
    }

    
    bool Board::checkState(){
        return (checkRows()||checkColumns()||checkDiagonals());
    }
    
    std::ostream& operator<<(std::ostream& str, Board const &b){
     
     for (int i=0; i<b.size; i++){
         for (int j=0; j<b.size; j++){
             str<<" "<<b.board[i][j]<<" |";
             
         }
         str<<std::endl;
         str<<"------------"<<std::endl;
     }
     return str;
 };

    //Player

